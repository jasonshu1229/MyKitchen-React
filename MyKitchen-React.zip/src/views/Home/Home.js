import React, { Component } from 'react';

class Home extends Component {
    state = {  }
    render() {
        return (
            <div>Home</div>
        );
    }
}

export default Home;