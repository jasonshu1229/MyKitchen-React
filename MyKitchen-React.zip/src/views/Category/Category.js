import React, { Component } from 'react';

class Category extends Component {
    state = {  }
    render() {
        return (
            <div>
                Category
            </div>
        );
    }
}

export default Category;