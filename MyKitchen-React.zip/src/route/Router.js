import {HashRouter as Router,Route,Redirect,Switch} from 'react-router-dom'
import React from 'react';
import App from '../App'
import Home from '../views/Home/Home'
import Category from '../views/Category/Category'
import Cart from '../views/Cart/Cart'
import User from '../views/User/User'
import Detail from '../views/Detail/Detail'
import Login from '../views/Login/Login';
import store from '../views/Redux/store'
import {Provider} from 'react-redux'


const router = 
    <Provider store={store}>
        <Router>
            <App>
                <Switch>
                    <Route path='/home' component={Home}/>
                    <Route path='/category' component={Category}/> 
                    <Route path='/cart' component={Cart}/>
                    <Route path='/user' component={User}/>  
                    <Route path='/login' component={Login}/>
                    <Route path="/detail/:myid" component={Detail}/> 
                    {/* <Route path="/detail" component={Detail}/> */}
                    <Redirect from='/' to='/home'></Redirect>
                </Switch>
            </App>
        </Router>
    </Provider>

export default router